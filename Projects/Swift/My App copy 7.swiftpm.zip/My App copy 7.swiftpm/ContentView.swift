import SwiftUI


struct ContentView: View {
    var body: some View {
        // define item prices & quantity
        let ham = 60
        let numh = 2
        let pat = 25
        let nump = 1
        let drink = 15
        let numd = 2
        // calculate & define the prices of items dependig on the quantity
        let sumh = ham*numh
        let sump = pat*nump
        let sumd = drink*numd
        // add all items to get the final price
        let sum = numh*ham + pat*nump + drink*numd
        VStack {
            Text("Menü Hesabı")
                .font(.largeTitle)
                .bold()
                .padding()
            Text("Hamburger: \(ham) x \(numh) = \(sumh)")
            Text("Patates: \(pat) x \(nump) = \(sump)")
            Text("İçecek: \(drink) x \(numd) = \(sumd)")
            Text("Toplam:\(sum) TL")
            // make the final price text smaller, blue and put distance on top
                .font(.subheadline)
                .foregroundStyle(.blue)
                .bold()
                .padding()
    
            
        }
    }
}

