import SwiftUI

private func to4(_ n: Int) -> Int { (n % 16 + 16) % 16 }
private func bin4(_ n: Int) -> String {
    let v = to4(n)
    let s = String(v, radix: 2)
    return String(repeating: "0", count: max(0, 4 - s.count)) + s
}

struct ContentView: View {
    @State private var value = 7      
    private let weights = [8, 4, 2, 1]
    
    var body: some View {
        VStack(spacing: 18) {
            
            Text("4-Bit ID Counter")
                .font(.system(size: 28, weight: .bold))
            
            
            HStack(spacing: 20) {
                Text("Decimal: \(to4(value))")
                Text("Binary: \(bin4(value))").monospaced()
            }
            .font(.title3)
            
            
            HStack(spacing: 12) {
                ForEach(weights, id: \.self) { w in
                    let on = (to4(value) & w) != 0
                    RoundedRectangle(cornerRadius: 12)
                        .fill(on ? Color.green.opacity(0.85) : Color.gray.opacity(0.25))
                        .frame(width: 56, height: 64)
                        .overlay(Text(on ? "1" : "0").font(.headline).monospaced())
                }
            }
            
            
            HStack(spacing: 12) {
                ForEach(weights, id: \.self) { w in
                    Text("\(w)")
                        .font(.caption)
                        .frame(width: 56)
                        .foregroundStyle(.secondary)
                }
            }
            
            
            HStack(spacing: 12) {
                Button("Enroll (+1)") {
                    value = to4(value + 1)     
                }
                .buttonStyle(.borderedProminent)
                
                Button("Reset (0)") { value = 0 }
                    .buttonStyle(.bordered)
                
                Button("Log to Console") {
                    print("Decimal: \(to4(value))  Binary: \(bin4(value))")
                }
                .buttonStyle(.bordered)
            }
            .padding(.top, 4)
            
            Spacer(minLength: 0)
        }
        .padding(20)
    }
}

#Preview {
    ContentView()
        .preferredColorScheme(.dark)  
}
