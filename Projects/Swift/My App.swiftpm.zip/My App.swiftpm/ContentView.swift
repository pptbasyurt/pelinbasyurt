// 28 September 2025
import SwiftUI

// Function to convert a decimal number to binary
func convertToBinary(_ number: Int) -> String {
    if number == 0 { return "0" }
    var num = number
    var binary = ""
    while num > 0 {
        let remainder = num % 2
        binary = String(remainder) + binary
        num = num / 2
    }
    return binary
}

// Function to make sure the binary number is always 4 digits
func padded4Bit(_ number: Int) -> String {
    let n = ((number % 16) + 16) % 16
    let raw = convertToBinary(n)
    return String(repeating: "0", count: max(0, 4 - raw.count)) + raw
}

// Main SwiftUI View
struct ContentView: View {
    @State private var studentID: Int = 0
    @State private var showOverflow = false
    private let bitValues = [8, 4, 2, 1]
    
    // Count how many scoops we have
    @State private var scoopCount: Int = 0
    
    var body: some View {
        // --- ICE CREAM (fixed) ---
        ZStack {
            VStack(spacing: 0) {
                // Scoops stacked so the bottom scoop touches the cone
                ZStack {
                    ForEach(0..<scoopCount, id: \.self) { index in
                        Circle()
                            .frame(width: 80, height: 80)
                            .foregroundColor(scoopColor(for: index))
                            .shadow(radius: 4, y: 2)
                            .offset(y: -CGFloat(index) * 60) // consistent stack
                    }
                }
                .padding(.bottom, -20) // brings scoops into the cone’s top edge
                
                // Narrow, pointy cone (SF Symbol triangle, flipped)
                Image(systemName: "triangle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100, height: 120) // narrower + pointier
                    .rotationEffect(.degrees(180))
                    .foregroundColor(.orange)
                    .shadow(radius: 8, y: 6)
            }
        }
        // --- END ICE CREAM ---
        
        // VStack for all the text and buttons
        VStack(spacing: 20) {
            Text("4-bit Student Code")
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(.purple)
            
            Text("Decimal: \(studentID)")
                .font(.title2)
                .foregroundColor(.gray)
            
            Text("Binary: \(padded4Bit(studentID))")
                .font(.title3).monospaced()
            
            // Display the 4 boxes for the binary bits
            HStack(spacing: 12) {
                ForEach(bitValues, id: \.self) { value in
                    let isActive = (studentID & value) == value
                    RoundedRectangle(cornerRadius: 12)
                        .fill(isActive ? Color.blue : Color.gray.opacity(0.3))
                        .frame(width: 50, height: 60)
                        .overlay(
                            VStack(spacing: 4) {
                                Text(isActive ? "1" : "0")
                                    .font(.headline).monospaced()
                                    .foregroundColor(isActive ? .white : .black)
                                Text("\(value)")
                                    .font(.caption).foregroundColor(.black.opacity(0.6))
                            }
                        )
                }
            }
            
            if showOverflow {
                Text("OVERFLOW!")
                    .font(.title2).bold()
                    .foregroundColor(.red)
            }
            
            // Buttons to increment and reset
            HStack(spacing: 12) {
                Button(action: {
                    let wasMax = (studentID == 15)
                    studentID = (studentID + 1) & 0xF
                    if wasMax {
                        showOverflow = true
                        scoopCount += 1
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            showOverflow = false
                        }
                    }
                }) {
                    Text("Increment (+1)")
                        .padding(8)
                        .background(Color.blue.opacity(0.7))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                
                Button(action: {
                    studentID = 0
                    showOverflow = false
                    scoopCount = 0
                }) {
                    Text("Reset")
                        .padding(8)
                        .background(Color.gray.opacity(0.5))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
            
            // Presets
            HStack(spacing: 8) {
                ForEach([2,5,10,14], id: \.self) { preset in
                    Button(action: { studentID = preset }) {
                        Text("Set \(preset)")
                            .padding(6)
                            .background(Color.purple.opacity(0.7))
                            .foregroundColor(.white)
                            .cornerRadius(6)
                    }
                }
            }
        }
        .padding()
    }
    
    // Function to assign colors to each scoop
    func scoopColor(for index: Int) -> Color {
        let colors: [Color] = [.pink, .mint, .yellow, .orange, .red, .green, .cyan, .brown]
        return colors[index % colors.count]
    }
}

