import SwiftUI


func initialTimeForLevel(level: Int) -> Int {
    if level == 1 {
        return 20
    } else if level == 2 {
        return 18
    } else if level == 3 {
        return 16
    } else if level == 4 {
        return 14
    } else {
        return 8
    }
}

func runConsoleSimulation() {
    for level in 1...5 {
        let total = initialTimeForLevel(level: level)
        print("— Level \(level) starts at \(total)s —")
        for t in stride(from: total, through: 0, by: -1) {
            if t > 0 {
                print("Level \(level) — time remaining: \(t)s")
            } else {
                print("TIME UP! Restarting clock…")
            }
        }
    }
}


struct ContentView: View {
    // Game state
    @State private var level: Int = 1
    @State private var timeLeft: Int = initialTimeForLevel(level: 1)
    @State private var totalTime: Int = initialTimeForLevel(level: 1)
    
    // Player
    @State private var playerX: CGFloat = 0.15       
    private let playerSize: CGFloat = 44
    
    // Goal
    private let goalX: CGFloat = 0.88                     
    // Obstacles 
    @State private var obsX: CGFloat = .random(in: 0.1...0.9)  
    @State private var obsY: CGFloat = -0.15                  
    @State private var obsSpeed: CGFloat = 0.25                
    private let obsSize = CGSize(width: 70, height: 20)
    
    // Flow
    @State private var showBanner: String? = nil
    @State private var isRunning: Bool = true
    
    // Timers
    @State private var animTimer = Timer.publish(every: 1.0/60.0, on: .main, in: .common).autoconnect()
    @State private var secTimer  = Timer.publish(every: 1.0,      on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack(spacing: 16) {
            
            // Title, Level/Time
            VStack(spacing: 6) {
                Text("Clock Game – Frog Escape")
                    .font(.title2).bold()
                HStack {
                    Text("Level \(level)")
                        .font(.headline)
                    Spacer()
                    Text("⏱ \(timeLeft)s")
                        .font(.headline).monospacedDigit()
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal)
            
            // Shrinking time bar
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.gray.opacity(0.2))
                    Capsule()
                        .fill(timeLeft > 0 ? Color.green : Color.red)
                        .frame(width: max(0, geo.size.width * CGFloat(timeLeft) / CGFloat(max(1, totalTime))))
                        .animation(.linear(duration: 0.2), value: timeLeft)
                }
            }
            .frame(height: 10)
            .padding(.horizontal)
            
            // Game area
            GeometryReader { geo in
                ZStack {
                    // Background
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color.black.opacity(0.9))
                        .overlay(RoundedRectangle(cornerRadius: 16)
                            .stroke(.white.opacity(0.08)))
                    
                    // Goal zone 
                    VStack {
                        Spacer()
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.green.opacity(0.25))
                            .overlay(Text("Goal")
                                .font(.caption).bold().foregroundColor(.green))
                            .frame(width: 70, height: 70)
                            .position(x: goalX * geo.size.width, y: geo.size.height * 0.8)
                    }
                    
                    // Obstacle
                    Rectangle()
                        .fill(Color.red.opacity(0.8))
                        .frame(width: obsSize.width, height: obsSize.height)
                        .shadow(radius: 6, y: 2)
                        .position(x: obsX * geo.size.width,
                                  y: max(0, obsY) * geo.size.height)
                    
                    // Player (frog/ball)
                    Circle()
                        .fill(Color.cyan)
                        .frame(width: playerSize, height: playerSize)
                        .shadow(radius: 6, y: 2)
                        .position(x: playerX * geo.size.width,
                                  y: geo.size.height * 0.8)
                    
                    // Banners
                    if let banner = showBanner {
                        Text(banner)
                            .font(.headline).bold()
                            .padding(.horizontal, 14).padding(.vertical, 8)
                            .background(Capsule().fill(banner == "OVERFLOW!" ? Color.red : Color.purple))
                            .foregroundStyle(.white)
                            .shadow(radius: 6, y: 3)
                            .transition(.scale.combined(with: .opacity))
                    }
                }
                .onReceive(animTimer) { _ in
                    guard isRunning else { return }
                    // Move obstacle
                    obsY += obsSpeed / 60.0
                    // Respawn when it leaves the screen
                    if obsY > 1.15 {
                        obsY = -0.15
                        obsX = .random(in: 0.1...0.9)
                    }
                    // Collision check
                    let playerRect = CGRect(
                        x: playerX * geo.size.width - playerSize/2,
                        y: geo.size.height * 0.8 - playerSize/2,
                        width: playerSize, height: playerSize
                    )
                    let obstacleRect = CGRect(
                        x: obsX * geo.size.width - obsSize.width/2,
                        y: max(0, obsY) * geo.size.height - obsSize.height/2,
                        width: obsSize.width, height: obsSize.height
                    )
                    if playerRect.intersects(obstacleRect) {
                        overflowReset() // crash
                    }
                    // Win check (player center crossed goal zone)
                    if playerX >= goalX {
                        levelUp()
                    }
                }
                .onReceive(secTimer) { _ in
                    guard isRunning else { return }
                    if timeLeft > 0 {
                        timeLeft -= 1
                    } else {
                        overflowReset() // time up
                    }
                }
            }
            .frame(height: 360)
            .padding(.horizontal)
            
            // Controls
            HStack(spacing: 12) {
                Button("◀︎") { move(-1) }
                    .font(.title2).bold()
                    .frame(width: 70, height: 44)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(0.15)))
                Button("▶︎") { move(1) }
                    .font(.title2).bold()
                    .frame(width: 70, height: 44)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(0.15)))
                Spacer()
                Button("Reset Level") {
                    resetLevel(keepLevel: true)
                }
                .buttonStyle(.bordered)
                Button("Run Console Simulation") {
                    runConsoleSimulation()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
        .preferredColorScheme(.dark)
        .onAppear {
            // Start fresh every run
            resetLevel(keepLevel: false)
        }
    }
    
    // MARK: - Game Logic
    
    private func move(_ dir: Int) {
        withAnimation(.easeOut(duration: 0.12)) {
            playerX = min(0.98, max(0.02, playerX + CGFloat(dir) * 0.06))
        }
    }
    
    private func levelUp() {
        isRunning = false
        showBanner = "LEVEL UP!"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
            level += 1
            totalTime = initialTimeForLevel(level: level)
            timeLeft  = totalTime
            obsSpeed += 0.05        // a bit faster each level
            playerX = 0.15
            obsY = -0.15
            obsX = .random(in: 0.1...0.9)
            showBanner = nil
            isRunning = true
        }
    }
    
    private func overflowReset() {
        isRunning = false
        showBanner = "OVERFLOW!"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
            resetLevel(keepLevel: true)
            showBanner = nil
            isRunning = true
        }
    }
    
    private func resetLevel(keepLevel: Bool) {
        if !keepLevel { level = 1 }
        totalTime = initialTimeForLevel(level: level)
        timeLeft  = totalTime
        playerX = 0.15
        obsSpeed = 0.25 + CGFloat(level - 1) * 0.05
        obsY = -0.15
        obsX = .random(in: 0.1...0.9)
    }
}
