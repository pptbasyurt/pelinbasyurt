import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "rectangle")
                .imageScale(.large)
                .foregroundColor(.yellow)
            Text("Hello")
                .padding()
                .font(.caption)
                .foregroundColor(.blue)
            Text("Hello")
                .font(.title)
                .foregroundColor(.red)
                .padding()
            Text("Hello")
                .padding()
                .foregroundColor(.green)
            
 
        }
    }
}
