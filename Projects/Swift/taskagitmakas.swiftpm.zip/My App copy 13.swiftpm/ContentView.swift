import SwiftUI

struct ContentView: View {
    
    let secimler = ["✊", "🤚", "✌️"]
    
    @State private var kullaniciSecimi = ""
    @State private var bilgisayarSecimi = ""
    @State private var result = "secim yap"
    
    func rastgeleBilgisayarsecimi() -> String {
        return secimler.randomElement()!
    }
    
    func kazanan(kullanici: String, bilgisayar: String) -> String {
        if kullanici == bilgisayar {
            return "berabere"
        }
        
        switch (kullanici, bilgisayar) {
        case ("✊", "✌️"), ("🤚", "✊"), ("✌️", "🤚"):
            return "kazandin"
        default:
            return "kaybettin"
        }
    }
    
    func play(_ secim: String) {
        kullaniciSecimi = secim
        bilgisayarSecimi = rastgeleBilgisayarsecimi()
        result = kazanan(kullanici: kullaniciSecimi, bilgisayar: bilgisayarSecimi)
    }
    
    var body: some View {
        VStack(spacing: 30) {
            
            Text("Taş Kağıt Makas oyunu")
                .font(.largeTitle)
            
            HStack(spacing: 30) {
                ForEach(secimler, id: \.self) { secim in
                    Button {
                        play(secim)
                    } label: {
                        Text(secim)
                            .font(.system(size: 100))
                    }
                }
            }
            
            Text("Kullanıcı: \(kullaniciSecimi)")
            Text("Bilgisayar: \(bilgisayarSecimi)")
            Text(result)
                .font(.title2)
                .bold()
        }
        .padding()
    }
}

