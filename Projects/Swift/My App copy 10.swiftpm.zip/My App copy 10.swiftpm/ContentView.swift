//04.09.25 
import SwiftUI

struct ContentView: View {
    @State private var angle: Double = 0
    @State private var tapCount: Int = 0
    @State private var hour: Int = 0
    
    var isNight: Bool {
        let mod = tapCount % 24
        return mod < 12
    }
    
    var body: some View {
        let appleDistinguishedEducator = isNight ? Color(.orange): Color(.gray)
        let FablabCoordinator = isNight ? Text("a.m.") : Text("p.m.")
        
        ZStack {
            appleDistinguishedEducator
              
            FablabCoordinator
                .offset(y: 200)
            Text("hour: \(hour)")
                .offset(y: 280)
                
            Circle()
                .fill(Color.white)
                .frame(width: 300, height: 300)
            
            ZStack {
                Rectangle()
                    .fill(Color.black)
                    .frame(width: 8, height: 135)
                    .offset(y: -70)
                
                Rectangle()
                    .fill(Color.black)
                    .frame(width: 8, height: 80)
                    .offset(y: -50)
            }
            .rotationEffect(.degrees(angle))
            
            Circle()
                .fill(Color.black)
                .frame(width: 12, height: 12)
        }
        .onTapGesture {
            angle += 15
            tapCount += 1
            hour += 1
            if hour == 24 {hour = 0 }
            
        }
        .animation(.easeInOut(duration: 0.2), value: angle)

    }
}
